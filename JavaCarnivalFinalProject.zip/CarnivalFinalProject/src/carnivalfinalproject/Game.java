/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carnivalfinalproject;

/**
 *
 * @author setup
 */
import java.util.Random;
import java.util.ArrayList;
public class Game 
{
    ArrayList<String> prizes = new ArrayList<>();
    Customer person = new Customer();

    
    //each game method rolls a number between 1-4 and depening on the number choosen they can get a certian prize
    //prizes are different for each game method
    public void WaterShooter()
    {
        
        Random rand = new Random();
        int num = rand.nextInt(4) + 1;
        String prize = "";
        switch(num)
        {
          
            case 1: prize = "You won a stuffed bear!";
            prizes.add("Stuffed bear");
            break;
            case 2: prize = "You won a plastic bear!";
            prizes.add("Plastic bear");
            break;
            case 3: prize = "You won a bear key chain!";
            prizes.add("Bear key chain");
            break;
            case 4: prize = "You lost, you didn't win anything";
        }
        System.out.println("Playing WaterShooter, the result is: " + prize);
        
    }
    // A display method to display the prizes using a for-each loop
    public void display()
    {
        if (!prizes.isEmpty()) 
        {
            System.out.println("You won these prizes: ");
            for (String str : prizes)
            {
                System.out.println(str);
            }
        }
    }
    //Balloon toss game
    public void BalloonDartToss()
    {
        Random rand = new Random();
        int num = rand.nextInt(4) + 1;
        String prize = "";
        switch(num)
        {
            case 1: prize = "You won a stuffed tiger!";
            prizes.add("Stuffed tiger");
            break;
            case 2: prize = "You won a plastic tiger!";
            prizes.add("Plastic tiger");
            break;
            case 3: prize = "You won a tiger key chain!";
            prizes.add("Tiger key chain");
            break;
            case 4: prize = "You lost, you didn't win anything";
        }
        System.out.println("Playing Balloon Dart Toss, the result is: " + prize);
       
    }
    //ring toss game
    public void RingToss()
    {
        Random rand = new Random();
        int num = rand.nextInt(4) + 1;
        String prize = "";
        switch(num)
        {
            case 1: prize = "You won a stuffed pig!";
            prizes.add("Stuffed pig");
            break;
            case 2: prize = "You won a plastic pig!";
            prizes.add("Plastic pig");
            break;
            case 3: prize = "You won a pig key chain!";
            prizes.add("pig key chain");
            break;
            case 4: prize = "You lost, you didn't win anything";
        }
        System.out.println("Playing Ring Toss, the result is: " + prize);
    }
}

