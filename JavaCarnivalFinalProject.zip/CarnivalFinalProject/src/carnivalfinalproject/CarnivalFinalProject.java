/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carnivalfinalproject;

/**
 *
 * @author setup
 */
import java.util.ArrayList;
import java.util.Scanner;
public class CarnivalFinalProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Game game = new Game();
        Food food = new Food();
        Scanner sc = new Scanner(System.in);
        System.out.println("Final project by Joshua Larsen\n");
        
        System.out.println("Welcome to the Carnival!");
        System.out.print("What is your name? ");
        String customerName = sc.next();
        Customer person = new Customer(customerName);
        int answer = 0;
        //It keeps promting the user until the input a 9
        while(answer != 9)
        {
        //Let the user know the number of tickets they have
        System.out.print("\nYou have " + person.tickets + " Tickets");
        //list the rest of the options they can choose from
        System.out.print("\n1. Water Shooter          ");
        System.out.println("5. Ferris Wheel");
        System.out.print("2. Balloon Dart Toss      ");
        System.out.println("6. Carousel");
        System.out.print("3. Ring Toss              ");
        System.out.println("7. Get Food");
        System.out.print("4. Add Tickets            ");
        System.out.println("8. Eat Food");
        System.out.println("9. Exit Carnival");
        System.out.print("What would you like to do? ");
        answer = sc.nextInt();
        
        
        //There is a function call check price, it checks if the user has enough tickets for the option they choose
            if (!person.checkPrice(answer)) 
            {
                System.out.println("Don't have enough tickets!");
            }
            else
            {
                //The switch takes whatever was choosen and makes sure it runs the method that is needed
                switch(answer)
                {
                    case 1: game.WaterShooter();
                    person.cost = 4;
                    person.tickets -= person.cost;
                    break;
                    case 2: game.BalloonDartToss();
                    person.cost = 4;
                    person.tickets -= person.cost;
                    break;
                    case 3: game.RingToss();
                    person.cost = 4;
                    person.tickets -= person.cost;
                    break;
                    case 4: person.AddTickets();
                    break;
                    case 5: person.ride(answer);
                    break;
                    case 6: person.ride(answer);
                    break;
                    case 7: person.food();
                    break;
                    case 8: System.out.println(food.EatFood(person.hands));
                    person.eat();
                    break;
                    case 9: break;
                    default: System.out.println("\nplease put in valid input");
                    break;
                }
            }
        
       
        }
        person.leave();
        game.display();
    }
    
}
