/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carnivalfinalproject;

/**
 *
 * @author setup
 */
public class Ride 
{
    
    //this just checks the input to see what ride the user choose
    public String TheRide(int ride)
    {
        if (ride == 5)
        {
            return "Enjoy the Ferris Wheel ride!";
        }
        else if(ride == 6)
        {
            return "Enjoy the Carousel ride!";
        }
        else
        {
            return "Invalid Input";
        }
    }
    

}
