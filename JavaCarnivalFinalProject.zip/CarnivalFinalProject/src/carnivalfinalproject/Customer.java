/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carnivalfinalproject;

/**
 *
 * @author setup
 */
import java.util.ArrayList;
import java.util.Scanner;
public class Customer 
{
    ArrayList<String> hands = new ArrayList<>();
    String customer = "";
    int tickets = 20;
    int cost;
    Scanner sc = new Scanner(System.in);
    Customer()
    {
        
    }
    Customer(String name)
    {
       customer = name;
    }
    //when they choose to add tickets it adds 10 tickets
    public void AddTickets()
    {
        tickets += 10;
        System.out.println("Added 10 tickets");
    }
    //this gets information from the food class and puts it and a method in the customer
    public void food()
    {
        Food food = new Food();
        System.out.println("Food Choices");
        System.out.print("1. Drink    ");
        System.out.println("3. Popcorn");
        System.out.print("2. Hot Dog  ");
        System.out.println("4. Cotton Candy");
        System.out.print("Which one do you want? ");
        int answer = sc.nextInt();
        
        //if there is nothing in the users hand they can buy more food
        if(!checkHands())
        {
        cost = food.GetFood(answer);
        //cost would only equal zero if they put in any other answer than 1-4
            if (cost == 0) 
            {
                System.out.println("please put in valid input");   
            }
            else
            {
                tickets -= cost;
                System.out.println("Enjoy your " + food.curfood);
                hands.add(food.curfood);
            }
        }
        
    }
    //this method ask the user what to eat and checks the answer then removes what ever the user chooses to eat
    public void eat()
    {
        if (!hands.isEmpty()) 
            {
                System.out.print("What Item you own would you like to eat? ");
                int eat = sc.nextInt();
                if(eat - 1 > hands.size() - 1)
                {
                    System.out.println("please put in valid input");  
                }
                else
                {
                    System.out.println("The " + hands.get(eat - 1) + " tasted great!");
                    hands.remove(eat - 1);
                }
            }

    }
    //this checks if your hands are full or not
    public boolean checkHands()
    {
        if (hands.size() >= 2)
        {
            System.out.print("Your hands are full! you can't carry anymore food! eat something to buy more food");
            return true;
        }
        else
        {
            return false;
        }
    }
    //this method gets informtion from the ride class and assigns the cost or price of the ride 
    public void ride(int answer)
    {
        Ride rd = new Ride();
        cost = 6;
        tickets -= cost;
        System.out.print( rd.TheRide(answer) );
    }
    //this checks if the user has enough tickets, and the add verable is just checks if it the user wants the add tickets method and if they do it returns true
    public boolean checkPrice(int add)
    {
        if (add == 4) 
        {
            return true;
        }
        return cost <= tickets;
    }
    //this just prints the goodbye and makes sure that the customers name is printed
    public void leave()
    {
        System.out.println("I hope you had a good time " + customer + "!");
    }
    
    
}
