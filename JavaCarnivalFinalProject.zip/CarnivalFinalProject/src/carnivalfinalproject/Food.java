/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carnivalfinalproject;

import java.util.ArrayList;

/**
 *
 * @author setup
 */
public class Food 
{
   
    String[] food = new String[]
    {
        "Drink", 
        "Hot Dog", 
        "Popcorn", 
        "Cotton Candy"
    };
    
    Customer person = new Customer();
    String curfood = "";
    public int GetFood(int fooditem)
    {

        //returns Ticket cost
        //return the value of tickets to subtract from the total
        //Also assigns a variable so the customer class can print out what food they got
        //use's array to hold all the food items
        switch(fooditem)
        {
            case 1:
                curfood = food[0];
                return 3;
            case 2:
                curfood = food[1];
                return 5;
            case 3:
                curfood = food[2];
                return 5;
            case 4:
                curfood = food[3];
                return 5;
            default: return 0;
        }

 
    }

    // this checks if they have bought any food
    public String EatFood(ArrayList array)
    {   
        if(array.size() >= 2)
        {
          return "1. " + (String) array.get(0) + " 2. " + (String) array.get(array.size() - 1) ;
        }
        else if(array.size() >= 1)
        {
            return "1. " + (String) array.get(0);
        }
        else
        {
            return "You haven't bought any food, go buy some food first!";
        }
    }
}
